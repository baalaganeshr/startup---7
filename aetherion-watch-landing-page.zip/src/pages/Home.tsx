import { motion, useScroll, useTransform } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Home() {
  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '50%']);

  return (
    <>
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <motion.div 
          style={{ y }}
          className="absolute inset-0 z-0"
        >
          <img 
            src="https://images.unsplash.com/photo-1523170335258-f5ed11844a49?q=80&w=2080&auto=format&fit=crop" 
            alt="Aetherion Watch" 
            className="w-full h-full object-cover opacity-90"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#050505]/20 to-[#050505]"></div>
        </motion.div>

        <div className="relative z-10 flex flex-col items-center text-center px-4 mt-20">
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xs tracking-[0.4em] uppercase text-[#C5A059] mb-6"
          >
            The New Standard
          </motion.p>
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.4 }}
            className="serif text-6xl md:text-8xl lg:text-[110px] leading-[0.9] font-light tracking-tight mb-8"
          >
            Time, <br />
            <span className="italic font-light text-[#C5A059]">Redefined.</span>
          </motion.h1>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1 }}
            className="flex flex-col items-center gap-4"
          >
            <p className="max-w-md text-sm md:text-base text-[#F5F2ED]/70 font-light leading-relaxed tracking-wide">
              A masterpiece of horology. Forged from aerospace-grade titanium, powered by a revolutionary tourbillon movement.
            </p>
            <Link to="/collection" className="mt-10 flex items-center gap-3 border-b border-[#C5A059] pb-2 text-[11px] tracking-[0.2em] uppercase hover:text-[#C5A059] transition-colors group">
              Discover the Collection
              <ArrowRight size={16} className="group-hover:translate-x-2 transition-transform" />
            </Link>
          </motion.div>
        </div>

        <div className="absolute bottom-12 left-6 hidden md:block">
          <div className="vertical-text text-[#F5F2ED]/50">Est. 2026</div>
        </div>
        <div className="absolute bottom-12 right-6 hidden md:block">
          <div className="vertical-text text-[#F5F2ED]/50">Swiss Made</div>
        </div>
      </section>

      {/* Teaser Section */}
      <section className="py-32 px-6 md:px-12 lg:px-24 bg-[#0A0A0A]">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="h-[60vh]"
          >
            <img 
              src="https://images.unsplash.com/photo-1587836374828-cb4387df3eb7?q=80&w=2000&auto=format&fit=crop" 
              alt="Lifestyle 1" 
              className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
              referrerPolicy="no-referrer"
            />
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex flex-col justify-center"
          >
            <span className="text-xs tracking-[0.3em] uppercase text-[#C5A059] mb-4 block">The Heritage</span>
            <h2 className="serif text-4xl md:text-5xl font-light mb-8 leading-tight">
              A legacy of <br/> <span className="italic font-light text-[#C5A059]">excellence.</span>
            </h2>
            <p className="text-[#F5F2ED]/70 font-light leading-relaxed tracking-wide mb-10">
              Every Aetherion timepiece is the result of over 400 hours of meticulous hand-craftsmanship by master horologists in Geneva. We didn't set out to make another watch. We set out to challenge the very concept of timekeeping.
            </p>
            <Link to="/philosophy" className="inline-flex items-center gap-3 text-[11px] tracking-[0.2em] uppercase hover:text-[#C5A059] transition-colors group w-max">
              Read Our Philosophy
              <ArrowRight size={16} className="group-hover:translate-x-2 transition-transform" />
            </Link>
          </motion.div>
        </div>
      </section>
    </>
  );
}
